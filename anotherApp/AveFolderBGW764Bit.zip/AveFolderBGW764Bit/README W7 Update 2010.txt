Update to Ave's Background Changer for Windows 7

LeeWhittington@Deviantart


Added Registry Entries to Ave's patch the application to work with Windows 7.
Still integrates into the Folders Customize this Folder Right-Click Menu Option
Enables Extended Tiles to Folders except My Computer and Users Documents*
*Keep Tile in My Computer and Users Documents allows user to still view Drives with Capacity Progressbar under Drives


All functions in Ave's still work the same

Side Effect of Ave's in Windows 7:
If you remove a background and have Shadows selected it will leave traces of images behind items in a folder
Workaround for this is to just make sure you unselect Shadow if you remove the background






Found registry fix by pure accident from Winhelponline from tutorial by Ramesh Srinivasan
How to Disable Full Row Select in Explorer in Windows 7?
http://www.winhelponline.com/blog/disable-full-row-select-explorer-windows-7/

with a few modifications that worked for patching Windows 7


This patch forces Windows 7 to use the standard list view control used in Windows Vista, instead of DirectUIHWND



Credit still goes to Andreas for the Shell integration so give thanks to him